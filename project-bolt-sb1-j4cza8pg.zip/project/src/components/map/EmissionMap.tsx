import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Circle, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

interface EmissionMapProps {
  forecastHours: number;
}

// List of hotspots with their coordinates and details
const getHotspots = (forecastHours: number) => {
  // Base hotspots (current emissions)
  const baseHotspots = [
    {
      id: 1,
      position: [40.7128, -74.006], // New York City
      intensity: 85,
      radius: 20000,
      name: 'NYC Metropolitan Area',
      source: 'Urban emissions',
    },
    {
      id: 2,
      position: [34.0522, -118.2437], // Los Angeles
      intensity: 78,
      radius: 25000,
      name: 'Los Angeles Basin',
      source: 'Industrial & vehicle emissions',
    },
    {
      id: 3,
      position: [41.8781, -87.6298], // Chicago
      intensity: 65,
      radius: 15000,
      name: 'Chicago Industrial Zone',
      source: 'Manufacturing & transport',
    },
    {
      id: 4,
      position: [29.7604, -95.3698], // Houston
      intensity: 82,
      radius: 18000,
      name: 'Houston Energy Corridor',
      source: 'Oil & gas processing',
    },
    {
      id: 5,
      position: [37.7749, -122.4194], // San Francisco
      intensity: 58,
      radius: 12000,
      name: 'Bay Area',
      source: 'Urban & tech industry',
    },
  ];

  // Simulate dispersion of emissions based on forecast hours
  if (forecastHours === 0) {
    return baseHotspots;
  }
  
  // Apply transformations to simulate dispersion over time
  return baseHotspots.map(hotspot => {
    // Simulate wind effect by shifting coordinates
    // This is a simplistic model - in a real app, would use actual wind data
    const lat = hotspot.position[0] + (forecastHours / 72) * 0.5; // Move north with time
    const lng = hotspot.position[1] + (forecastHours / 48) * 0.8; // Move east with time
    
    // Simulate dispersion by increasing radius and decreasing intensity
    const radiusMultiplier = 1 + (forecastHours / 24) * 0.5;
    const intensityReduction = (forecastHours / 24) * 15;
    
    return {
      ...hotspot,
      position: [lat, lng] as [number, number],
      radius: hotspot.radius * radiusMultiplier,
      intensity: Math.max(20, hotspot.intensity - intensityReduction),
    };
  });
};

const MapUpdater: React.FC<{ hotspots: any[] }> = ({ hotspots }) => {
  const map = useMap();
  
  useEffect(() => {
    if (hotspots.length > 0) {
      // Calculate bounds that include all hotspots
      const bounds = hotspots.reduce(
        (acc, hotspot) => acc.extend(hotspot.position),
        map.getBounds()
      );
      
      // Fit the map to these bounds with some padding
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [map, hotspots]);
  
  return null;
};

export const EmissionMap: React.FC<EmissionMapProps> = ({ forecastHours }) => {
  const hotspots = getHotspots(forecastHours);
  
  // Function to determine circle color based on intensity
  const getCircleColor = (intensity: number) => {
    if (intensity > 70) return '#ef4444'; // Red for high intensity
    if (intensity > 50) return '#f59e0b'; // Orange for medium intensity
    return '#22c55e'; // Green for low intensity
  };
  
  return (
    <div className="h-[500px] rounded-xl overflow-hidden">
      <MapContainer
        center={[39.8283, -98.5795]} // Center of the US
        zoom={4}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        <MapUpdater hotspots={hotspots} />
        
        {hotspots.map((hotspot) => (
          <Circle
            key={hotspot.id}
            center={hotspot.position}
            radius={hotspot.radius}
            pathOptions={{
              fillColor: getCircleColor(hotspot.intensity),
              fillOpacity: 0.5,
              color: getCircleColor(hotspot.intensity),
              weight: 1,
            }}
          >
            <Popup>
              <div className="p-1">
                <h4 className="font-bold">{hotspot.name}</h4>
                <p className="text-sm">Source: {hotspot.source}</p>
                <p className="text-sm">
                  Intensity: <span className="font-medium">{hotspot.intensity}</span>
                </p>
                <p className="text-sm">
                  Forecast: <span className="font-medium">{forecastHours}h</span>
                </p>
              </div>
            </Popup>
          </Circle>
        ))}
      </MapContainer>
    </div>
  );
};